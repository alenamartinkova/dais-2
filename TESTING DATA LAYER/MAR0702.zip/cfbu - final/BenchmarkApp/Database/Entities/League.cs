﻿using System;
namespace BenchmarkApp.Database.Entities
{
    public class League
    {
        public int leagueID { get; set; }
        public string name { get; set; }
        public int category { get; set; }

        public League()
        {
        }
    }
}
